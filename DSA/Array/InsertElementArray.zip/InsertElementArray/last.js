// add Element in first index without using method
let array = [11,12,13,14,15];
let add = 20;
array[array.length] = add;
console.log(array);






 