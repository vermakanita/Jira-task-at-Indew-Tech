// add Element in first index without using method
let array = [11,12,13,14,15];
let add = 20;
array.length = array.length+1;
for(let i = array.length-1 ; i>=0; i--) {    //  i=5
    array[i] = array[i-1]        
                                 // i-1 = 4
} array[0] = add;
console.log(array);






 