let a1 = [1,12,31,4,5];
let a2= [11,12,31,41,15];
let m =[];

for(let i =0 ;i<a1.length;i++){
    m[m.length]= a1[i];
    
}
for(let i =0 ;i<a2.length;i++){
    m[m.length]= a2[i];
    
}
console.log(m)









 